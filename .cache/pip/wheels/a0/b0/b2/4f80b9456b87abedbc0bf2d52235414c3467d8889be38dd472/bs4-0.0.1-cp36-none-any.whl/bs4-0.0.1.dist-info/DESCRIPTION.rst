Use `beautifulsoup4 <https://pypi.python.org/pypi/beautifulsoup4>`_ instead.


